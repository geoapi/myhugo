+++
# About/Biography widget.

date = "2016-04-20T00:00:00"
draft = false

widget = "about"

# Order that this section will appear in.
weight = 1

# List your academic interests.
[interests]
  interests = [
    "API Documentation",
    "Crowdsourcing",
    "Web Development"
  ]

# List your qualifications (such as academic degrees).
[[education.courses]]
  course = "PhD Student CSE"
  institution = "UNSW"
  year = 2014

[[education.courses]]
  course = "M.Sc. in Computer Science / Data Security"
  institution = "Univesity of Technology"
  year = 2006

[[education.courses]]
  course = "BSc in Computer Science"
  institution = "Babylon University"
  year = 2002
 
+++

# Biography

George Ajam is a PhD student at the UNSW CSE. His research interests include API documentation, and crowdsourcing.
 
