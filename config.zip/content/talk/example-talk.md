+++
date = "2017-01-01T00:00:00"
math = true
title = "Example Talk"
abstract = ""
abstract_short = ""
event = "Hugo Academic Theme Conference"
event_url = "https://example.org"
location = "London, United Kingdom"
selected = false
url_pdf = ""
url_slides = ""
url_video = ""
+++

Embed your slides or video here using [shortcodes](https://gcushen.github.io/hugo-academic-demo/post/writing-markdown-latex/). Further details can easily be added using *Markdown* and $\rm \LaTeX$ math code. 
